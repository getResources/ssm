package com.lqy.ssm.dao;

import com.lqy.ssm.bean.User;
import tk.mybatis.mapper.common.Mapper;

public interface UserMapper extends Mapper<User> {
	
	
	public User getById(Long userId);
}