package com.lqy.ssm.test.data;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.lqy.ssm.bean.User;
import com.lqy.ssm.dao.UserMapper;

/**
*@RunWith 注释标签是 Junit 提供的，用来说明此测试类的运行者，这里用了 SpringJUnit4ClassRunner，这个类是一个针对 Junit 运行环境的自定义扩展，用来标准化在 Spring 环境中 Junit4.5 的测试用例，例如支持的注释标签的标准化
*@ContextConfiguration 注释标签是 Spring test context 提供的，用来指定 Spring 配置信息的来源，支持指定 XML 文件位置或者 Spring 配置类名，这里我们指定 classpath 下的 /config/Spring-db1.xml 为配置文件的位置
*@Transactional 注释标签是表明此测试类的事务启用，这样所有的测试方案都会自动的 rollback，即您不用自己清除自己所做的任何对数据库的变更了
*/
/*@ContextConfiguration(locations= {"classpath:spring.xml"})*/
@ContextConfiguration(locations= "classpath:spring.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class TestMybatis extends AbstractJUnit4SpringContextTests{

	@Autowired
	private UserMapper userMapper;
	
	@Autowired
	private SqlSession sqlSession;
	
	@Test
	public void getUser() {
		User user = userMapper.selectByPrimaryKey(1L);
		System.out.println(user);
	}
	
	@Test
	public void updateUser() {
		User user = userMapper.selectByPrimaryKey(1L);
		System.out.println("更新前："+user);
		user.setUserName("名字更新了！");
		user.setAge(20);
		userMapper.updateByPrimaryKey(user);
		System.out.println("更新后："+user);
	}
	
	
	@Test
	public void saveUserBatch() {
		//使用sqlSession批量插入数据
		UserMapper m = sqlSession.getMapper(UserMapper.class);
		for(int i=0; i<1000; i++) {
			User user = new User();
			user.setUserName("姓名"+i);
			user.setAge(i);
			user.setEmail(i+"000@qq.com");
			m.insert(user);
		}
		System.out.println("批量插入数据执行完成！");
	}
	
	@Test
	public void page() {
		PageHelper.startPage(1, 5);
		List<User> users = userMapper.selectAll();
		PageInfo<User> pageInfo = new PageInfo<>(users);
		System.out.println("pageInfo="+pageInfo);
		List<User> userList = pageInfo.getList();
		for (User user : userList) {
			System.out.println("user="+user);
		}
	}
	
	
	@Test
	public void getById() {
		User user = userMapper.getById(2L);
		System.out.println(user);
	}
	
	
	
}
