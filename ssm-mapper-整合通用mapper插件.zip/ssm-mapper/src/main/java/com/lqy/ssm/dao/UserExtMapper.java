package com.lqy.ssm.dao;

import com.lqy.ssm.bean.UserExt;
import tk.mybatis.mapper.common.Mapper;

public interface UserExtMapper extends Mapper<UserExt> {
}