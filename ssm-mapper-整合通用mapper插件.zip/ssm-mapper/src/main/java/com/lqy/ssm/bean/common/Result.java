package com.lqy.ssm.bean.common;

import java.util.HashMap;
import java.util.Map;

public class Result {

	/**返回结果状态码*/
	private String code;
	/**返回结果状态码对应的提示信息*/
	private String message;
	/**返回结果包含的数据*/
	private Map<String, Object> dataMap = new HashMap<String, Object>();
	
	private static final String SUCCESS_CODE = "0";
	private static final String ERROR_CODE = "-1";
	
	public static Result success() {
		Result result = new Result();
		result.setCode(SUCCESS_CODE);
		result.setMessage("操作成功！");
		return result;
	}
	
	public static Result success(String message) {
		Result result = new Result();
		result.setCode(SUCCESS_CODE);
		result.setMessage(message);
		return result;
	}
	
	public static Result error() {
		Result result = new Result();
		result.setCode(ERROR_CODE);
		result.setMessage("操作失败！");
		return result;
	}
	
	public static Result error(String message) {
		Result result = new Result();
		result.setCode(ERROR_CODE);
		result.setMessage(message);
		return result;
	}
	
	public Result add(String key, Object value) {
		 this.getDataMap().put(key, value);
		 return this;
	}
	
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	public Map<String, Object> getDataMap() {
		return dataMap;
	}

	public void setDataMap(Map<String, Object> dataMap) {
		this.dataMap = dataMap;
	}
	
	
	
}
